package resources;

/**
 * Marker.
 */
public class Marker
{

}
