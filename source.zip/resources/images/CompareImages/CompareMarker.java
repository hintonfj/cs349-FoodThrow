package resources.images.CompareImages;

/**
 * Compare Marker.
 */
public class CompareMarker
{

}
