package resources.images.FillMaps;

/**
 * Fill marker.
 */
public class FillMarker
{

}
