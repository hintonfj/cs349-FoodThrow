package sound;

/**
 * Sound marker.
 */
public class SoundMarker
{

}
